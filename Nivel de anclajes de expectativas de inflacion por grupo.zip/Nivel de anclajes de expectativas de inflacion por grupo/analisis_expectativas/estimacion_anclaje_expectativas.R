# Cargar librerías necesarias
library(tidyverse)
library(nlme)
library(minpack.lm)

data_ms <- readxl::read_excel("./data/data.xlsx", sheet = "data_expect")

# Cargar datos (reemplazar con la ruta del archivo correcto)
data_inflacion <- data_ms %>%
  mutate(dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
         dev_pos = pmax(dl4_ipc - meta, 0),
         dev_neg = pmax(meta - dl4_ipc, 0),
         mas_meta = factor(dl4_ipc > meta)) %>%
  filter(!is.na(dl4_ipc))




#--------------------------------------------------------------------------------
# Asegurar que no haya valores NA en las variables clave
data_inflacion <- data_inflacion %>%
  filter(!is.na(exp_inf) & !is.na(dl4_ipc))

# Ver distribución de datos antes del ajuste
summary(data_inflacion$exp_inf)
summary(data_inflacion$dl4_ipc)

# Verificar colinealidad entre variables
cor_valor <- cor(data_inflacion$exp_inf, data_inflacion$dl4_ipc, use = "complete.obs")
print(paste("Correlación entre exp_inf y dl4_ipc:", round(cor_valor, 4)))

# Si la correlación es cercana a 1 o -1, alertar sobre colinealidad
if (abs(cor_valor) > 0.95) {
  warning("Las variables exp_inf y dl4_ipc están altamente correlacionadas. Esto podría afectar la estimación.")
}

# Normalizar `exp_inf` y `dl4_ipc` para mejorar la convergencia
data_inflacion <- data_inflacion %>%
  mutate(exp_inf_scaled = (exp_inf - min(exp_inf)) / (max(exp_inf) - min(exp_inf)),
         dl4_ipc_scaled = (dl4_ipc - min(dl4_ipc)) / (max(dl4_ipc) - min(dl4_ipc)))

# Definir función de anclaje sin intercorrelación
anclaje_modificado <- function(h, Kappa) {
  1 - exp(-h / (Kappa + 1e-6))  # Se suma 1e-6 para evitar divisiones por cero
}

# Valores iniciales ajustados automáticamente
Kappa_init <- runif(1, 5, 20)  # Valor aleatorio entre 5 y 20
ancla_init <- mean(data_inflacion$exp_inf_scaled, na.rm = TRUE)

# Imprimir valores iniciales para diagnóstico
print(paste("Valores iniciales: Kappa =", Kappa_init, "Ancla =", ancla_init))

# Estimación inicial con optim() para obtener valores razonables
modelo_opt <- optim(
  par = c(Kappa = Kappa_init, ancla = ancla_init),
  fn = function(params) {
    Kappa <- params[1]
    ancla <- params[2]
    
    pred <- anclaje_modificado(12, Kappa) * ancla + 
      (1 - anclaje_modificado(12, Kappa)) * data_inflacion$dl4_ipc_scaled
    sum((data_inflacion$exp_inf_scaled - pred)^2)  # Minimizar error cuadrático
  },
  method = "BFGS"
)

print("Parámetros estimados por optim():")
print(modelo_opt$par)

# Modelo no lineal usando nlsLM con valores iniciales de optim()
modelo_nls <- tryCatch({
  nlsLM(
    exp_inf_scaled ~ anclaje_modificado(12, Kappa) * ancla + 
      (1 - anclaje_modificado(12, Kappa)) * dl4_ipc_scaled,
    data = data_inflacion,
    start = list(Kappa = modelo_opt$par[1], ancla = modelo_opt$par[2])
  )
}, error = function(e) {
  print("Error en nlsLM, ajustando valores iniciales...")
  return(NULL)
})

# Si nlsLM falla, intentar con otro método
if (is.null(modelo_nls)) {
  modelo_nls <- lm(exp_inf_scaled ~ dl4_ipc_scaled, data = data_inflacion)
  print("Se usó regresión lineal en lugar de nlsLM debido a problemas de convergencia.")
}

# Mostrar resumen del modelo
summary(modelo_nls)

# Extraer parámetros estimados
coef(modelo_nls)

# Graficar resultados
data_inflacion %>%
  mutate(ajuste = predict(modelo_nls) * (max(exp_inf) - min(exp_inf)) + min(exp_inf)) %>%
  ggplot(aes(x = fecha)) +
  geom_line(aes(y = exp_inf, color = "Expectativa 12M")) +
  geom_line(aes(y = ajuste, color = "Modelo Ajustado")) +
  labs(title = "Estimación del Nivel de Anclaje de la Inflación",
       x = "Fecha", y = "Inflación (%)") +
  theme_minimal()




# Ajuste del modelo:  -----------------------------------------------------
# Asegurar datos limpios
data_inflacion <- na.omit(data_inflacion)

# Revisar datos antes de optimizar
summary(data_inflacion)
sum(is.na(data_inflacion))

# Modificar función de anclaje para evitar errores matemáticos
anclaje_variable <- function(h, kappa0, gamma1, gamma2, crisis_2008, crisis_petroleo, crisis_covid) {
  kappa_t <- pmax(kappa0 + gamma1 * crisis_2008 + gamma2 * crisis_petroleo + gamma2 * crisis_covid, 1e-6)
  1 - exp(-h / kappa_t)
}

# Ajustar valores iniciales
kappa0_init <- runif(1, 10, 30)
gamma1_init <- runif(1, 0.05, 1.5)
gamma2_init <- runif(1, 0.05, 1.5)
ancla_init <- max(0.01, mean(data_inflacion$exp_inf_scaled, na.rm = TRUE))

# Ejecutar optimización con control de errores
modelo_opt <- tryCatch({
  optim(
    par = c(kappa0 = kappa0_init, gamma1 = gamma1_init, gamma2 = gamma2_init, ancla = ancla_init),
    fn = function(params) {
      kappa0 <- params[1]
      gamma1 <- params[2]
      gamma2 <- params[3]
      ancla <- params[4]
      
      pred <- anclaje_variable(12, kappa0, gamma1, gamma2, 
                               data_inflacion$crisis_2008, 
                               data_inflacion$crisis_petroleo, 
                               data_inflacion$crisis_covid) * ancla + 
        (1 - anclaje_variable(12, kappa0, gamma1, gamma2, 
                              data_inflacion$crisis_2008, 
                              data_inflacion$crisis_petroleo, 
                              data_inflacion$crisis_covid)) * data_inflacion$dl4_ipc_scaled
      if (any(is.na(pred)) | any(is.infinite(pred))) return(Inf)
      sum((data_inflacion$exp_inf_scaled - pred)^2)
    },
    method = "BFGS"
  )
}, error = function(e) {
  print("Error en optim(), usando valores por defecto.")
  return(list(par = c(kappa0 = 20, gamma1 = 0.5, gamma2 = 0.5, ancla = 0.4)))
})

# Imprimir parámetros optimizados
print(modelo_opt$par)

# Continuar con nlsLM usando los parámetros ajustados
modelo_nls <- nlsLM(
  exp_inf_scaled ~ anclaje_variable(12, kappa0, gamma1, gamma2, 
                                    crisis_2008, crisis_petroleo, crisis_covid) * ancla + 
    (1 - anclaje_variable(12, kappa0, gamma1, gamma2, 
                          crisis_2008, crisis_petroleo, crisis_covid)) * dl4_ipc_scaled,
  data = data_inflacion,
  start = list(kappa0 = modelo_opt$par[1], gamma1 = modelo_opt$par[2], 
               gamma2 = modelo_opt$par[3], ancla = modelo_opt$par[4])
)

# Resumen del modelo
summary(modelo_nls)


# Graficar resultados del modelo ajustado
data_inflacion %>%
  mutate(ajuste = predict(modelo_nls) * (max(exp_inf) - min(exp_inf)) + min(exp_inf)) %>%
  ggplot(aes(x = fecha)) +
  
  # Expectativas de inflación reales
  geom_line(aes(y = exp_inf, color = "Expectativa 12M"), size = 1, alpha = 0.7) +
  
  # Modelo Ajustado
  geom_line(aes(y = ajuste, color = "Modelo Ajustado"), size = 1) +
  
  # Crisis económicas
  geom_vline(xintercept = as.numeric(data_inflacion$fecha[which.max(data_inflacion$crisis_2008)]), 
             linetype = "dashed", color = "red", alpha = 0.8) +
  geom_vline(xintercept = as.numeric(data_inflacion$fecha[which.max(data_inflacion$crisis_petroleo)]), 
             linetype = "dashed", color = "blue", alpha = 0.8) +
  geom_vline(xintercept = as.numeric(data_inflacion$fecha[which.max(data_inflacion$crisis_covid)]), 
             linetype = "dashed", color = "purple", alpha = 0.8) +
  
  # Etiquetas y diseño
  labs(title = "Estimación del Nivel de Anclaje de la Inflación con Crisis",
       subtitle = "Comparación entre la Expectativa de Inflación a 12M y el Modelo Ajustado",
       x = "Fecha",
       y = "Inflación (%)",
       color = "Serie") +
  
  theme_minimal() +
  scale_color_manual(values = c("Expectativa 12M" = "red", "Modelo Ajustado" = "blue")) +
  theme_em()


