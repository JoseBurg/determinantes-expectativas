# Cargar paquetes necesarios
# Nota: se debe correr el scripts de funciones impulso respuestas
library(vars)
library(lmtest)
library(tidyverse)
library(tseries)
library(forecast)

# 1️⃣ Cargar datos
data_econ <- data_ms %>% 
  select(fecha, exp_inf, tia_180, tipo_cambio = tcn, precio_petroleo = wti) %>% 
  drop_na()  # Eliminar valores faltantes

# Convertir en objeto de series de tiempo
ts_data <- ts(data_econ[,-1], start = c(2008, 1), frequency = 12)  # Series mensuales

# 2️⃣ Prueba de causalidad de Granger
granger_test_tpm <- grangertest(exp_inf ~ tia_180, order = 2, data = ts_data)
granger_test_tc <- grangertest(exp_inf ~ tipo_cambio, order = 2, data = ts_data)
granger_test_petroleo <- grangertest(exp_inf ~ precio_petroleo, order = 2, data = ts_data)

# Mostrar resultados
print(granger_test_tpm)
print(granger_test_tc)
print(granger_test_petroleo)

# 3️⃣ Modelo VAR
lag_selection <- VARselect(ts_data, lag.max = 10, type = "const")
optimal_lag <- lag_selection$selection["AIC(n)"]

# Ajustar modelo VAR
var_model <- VAR(ts_data, p = optimal_lag, type = "const")

# 4️⃣ Función de Respuesta al Impulso (IRF) para analizar impacto de shocks
irf_tpm <- irf(var_model, impulse = "tia_180", response = "exp_inf", n.ahead = 50, boot = TRUE)
irf_tc <- irf(var_model, impulse = "tipo_cambio", response = "exp_inf", n.ahead = 20, boot = TRUE)
irf_petroleo <- irf(var_model, impulse = "precio_petroleo", response = "exp_inf", n.ahead = 20, boot = TRUE)

# Graficar IRF
plot(irf_tpm, main = "Impacto de la TPM en Expectativas de Inflación")
plot(irf_tc, main = "Impacto del Tipo de Cambio en Expectativas de Inflación")
plot(irf_petroleo, main = "Impacto del Precio del Petróleo en Expectativas de Inflación")

# 5️⃣ Descomposición de varianza para ver qué variable explica mejor la variabilidad de exp_inf
fevd_var <- fevd(var_model, n.ahead = 20)
plot(fevd_var)




# 1️⃣ Cargar datos
data_econ <- data_ms %>% 
  select(fecha, exp_inf, tia_180, tipo_cambio = tcn, precio_petroleo = wti) %>% 
  drop_na()  # Eliminar valores faltantes

# Convertir en objeto de series de tiempo
ts_data <- ts(data_econ[,-1], start = c(2008, 1), frequency = 12)  # Series mensuales

# 2️⃣ Prueba de causalidad de Granger
granger_test_tpm <- grangertest(exp_inf ~ tia_180, order = 2, data = ts_data)
granger_test_tc <- grangertest(exp_inf ~ tipo_cambio, order = 2, data = ts_data)
granger_test_petroleo <- grangertest(exp_inf ~ precio_petroleo, order = 2, data = ts_data)

# Mostrar resultados
print(granger_test_tpm)
print(granger_test_tc)
print(granger_test_petroleo)

# 3️⃣ Modelo VAR
lag_selection <- VARselect(ts_data, lag.max = 10, type = "const")
optimal_lag <- lag_selection$selection["AIC(n)"]

# Ajustar modelo VAR
var_model <- VAR(ts_data, p = optimal_lag, type = "const")

# 4️⃣ Función de Respuesta al Impulso (IRF)
irf_tpm <- irf(var_model, impulse = "tia_180", response = "exp_inf", n.ahead = 50, boot = TRUE)
irf_tc <- irf(var_model, impulse = "tipo_cambio", response = "exp_inf", n.ahead = 50, boot = TRUE)
irf_petroleo <- irf(var_model, impulse = "precio_petroleo", response = "exp_inf", n.ahead = 50, boot = TRUE)

# 5️⃣ Convertir IRF en DataFrames para ggplot2
convert_irf_df <- function(irf_object, impulse_var) {
  data.frame(
    Periodo = 1:length(irf_object$irf[[impulse_var]]),
    Impulso = as.numeric(irf_object$irf[[impulse_var]]),  # Convertir a numérico
    Lower = as.numeric(irf_object$Lower[[impulse_var]]),  # Convertir a numérico
    Upper = as.numeric(irf_object$Upper[[impulse_var]])   # Convertir a numérico
  ) %>%
    drop_na()  # Eliminar posibles valores NA
}


df_irf_tpm <- convert_irf_df(irf_tpm, "tia_180")
df_irf_tc <- convert_irf_df(irf_tc, "tipo_cambio")
df_irf_petroleo <- convert_irf_df(irf_petroleo, "precio_petroleo")

# 6️⃣ Graficar en ggplot2
plot_irf <- function(df, title) {
  ggplot(df, aes(x = Periodo, y = Impulso)) +
    geom_line(color = "black", size = 1) +
    geom_ribbon(aes(ymin = Lower, ymax = Upper), fill = "gray50", alpha = 0.2) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
    labs(title = title, x = "Meses", y = "Impacto en Exp. Inflación") +
    theme_classic()
}

# Graficar los IRFs con ggplot2
plot_irf(df_irf_tpm, "Impacto de Tasa Activa a 180 días en Exp. Inflación")
plot_irf(df_irf_tc, "Impacto del Tipo de Cambio en Exp. Inflación")
plot_irf(df_irf_petroleo, "Impacto del Precio del Petróleo en Exp. Inflación")

# 7️⃣ Descomposición de varianza para ver qué variable explica mejor exp_inf
fevd_var <- fevd(var_model, n.ahead = 20)

# Convertir FEVD en DataFrame para ggplot2
fevd_df <- data.frame(
  Periodo = rep(1:20, times = 3),
  Variable = rep(c("tia_180", "tipo_cambio", "precio_petroleo"), each = 20),
  Contribución = c(fevd_var$exp_inf[, "tia_180"],
                   fevd_var$exp_inf[, "tipo_cambio"],
                   fevd_var$exp_inf[, "precio_petroleo"])
)

# Gráfico de Descomposición de Varianza
fevd_df |> 
  mutate(Variable = recode(
    Variable, "tia_180" = "Tasa activa", "precio_petroleo" = "Petroleo", "tipo_cambio" = "Tipo de cambio"
  )) |> 
ggplot(aes(x = Periodo, y = Contribución, fill = Variable)) +
  geom_bar(stat = "identity", position = "stack") +
  labs(title = "Descomposición de Varianza de Exp. Inflación",
       x = NULL, y = "Porcentaje de Variabilidad Explicada",
       fill = NULL
       ) +
  scale_fill_manual(values = c("Petroleo" = "#118ab2", "Tasa activa" = "#415a77", "Tipo de cambio" = "#778da9")) +
  theme_minimal() +
  theme(legend.position = "bottom")
