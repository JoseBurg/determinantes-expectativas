library(tidyverse)


data_ms <- readxl::read_excel("./data/data.xlsx", sheet = "data_expect")

data_ms <- data_ms %>%
  mutate(dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
         dev_pos = pmax(dl4_ipc - meta, 0),
         dev_neg = pmax(meta - dl4_ipc, 0),
         mas_meta = factor(dl4_ipc > meta)) %>%
  filter(!is.na(dl4_ipc))






# Estimación de modelo ----------------------------------------------------
# Escenario de alta y baja inflación

model_asi <- lm(exp_inf ~ dev_pos + dev_neg, data = data_ms)
model_alta_inflacion <- lm(exp_inf ~ dev_pos + dev_neg, data = data_ms |> 
                               filter(dl4_ipc > mean(dl4_ipc, na.rm = TRUE)))
model_baja_inflacion <- lm(exp_inf ~ dev_pos + dev_neg, data = data_ms |> 
                               filter(dl4_ipc < mean(dl4_ipc, na.rm = TRUE)))


stargazer::stargazer(model_asi, model_alta_inflacion, model_baja_inflacion, type = "text",
                     column.labels = c("General", "Inflación > Media", "Inflación < Media"),
                     covariate.labels = c("Desviación Positiva", "Desviación Negativa"),
                     notes.align = "l"
                     )







#                                                     TAREA ---------------
# 
# seria esto que se hizo para la expectativa globales, repetirlo para casa uno. tener un 
# panel grafico de esas por grupos arriba y la tabla con estos dos coeficientes debajo
# ---------------------------------------------------------
# imagina esta columna es la total, agregarle una columan con este resultado para cada serie. 
# Es decir uni. puesto de bolsa
# NOTA: ver tabla de estimacion de las expectativas "estimacion_exp_globales" 


# -----------------------------------------------------------
data_ms2 <- data_ms %>%
  mutate(across(tcn:fyb_price, .fns = ~ (.-lag(., 12)) / lag(., 12) * 100,
                .names = "dl12_{.col}"),
         across(tcn:fyb_price, .fns = ~ (.-lag(., 1)) / lag(., 12) * 100,
                .names = "dl1_{.col}")) %>%
  mutate(dev_pos = pmax(dl12_IPC - meta, 0),
         dev_neg = pmax(meta - dl12_IPC, 0),
         subsidio = if_else(fecha >= as.Date("2022-03-01"), 1, 0)) |> 
  filter(!is.na(dl12_IPC))

model_asi0 <- lm(exp_inf ~ dev_pos + dev_neg + dl12_wti, data = data_ms2)
model_asi1 <- lm(exp_inf ~ dev_pos*subsidio + dev_neg*subsidio + dl12_wti , data = data_ms2)

stargazer::stargazer(model_asi0,model_asi1, type = "text")





# Grupo economico  --------------------------------------------------------
expect_by_group <-
  readxl::read_excel("./data/expectativas_inflacion_grupo.xlsx") |> 
  rename(
    "inf_12" = inflacion_12,
    "inf_24" = inflacion_24) |> 
  select(-inf_24) |> 
  mutate(
    grupo = stringr::str_to_lower(grupo),
    periodo = as.Date(periodo)) |> 
  summarise(inf_12 = mean(inf_12, na.rm = TRUE),
            .by = c(periodo, grupo)) 


# expect_by_group |> 
  # pivot_wider(
  #   id_cols = periodo,
  #   names_from = grupo, 
  #   values_from = inf_12) |> 
  # janitor::clean_names() |> 
  # rename_with(
  #   ~paste0("exp_inf_", .),
  #   .cols = -periodo
  # )

# Gráficos ----------------------------------------------------------------

# 
# expect_by_group |> 
#   mutate(grupo = str_to_title(grupo)) |> 
#   ggplot(aes(periodo, inf_12)) + 
#   geom_line(aes(color = grupo)) + 
#   geom_hline(yintercept = 5) + 
#   geom_hline(yintercept = 4) + 
#   geom_hline(yintercept = 3) + 
#   facet_wrap(~grupo) +
#   theme_bw() +
#   labs(x = NULL, y = NULL) +
#   theme(
#     legend.position = "none"
#   )
# 
# #                Expectativas de inflación promedio vs Inflación interanual ---------
# 
# data_ms_filter <- data_ms |>  
#   filter(fecha >= "2016-08-01" & fecha < "2024-11-01") |> 
#   mutate(fecha = as.Date(fecha))
# 
# expect_by_group |> 
#   mutate(grupo = str_to_upper(grupo)) |> 
#   ggplot(aes(periodo, inf_12)) + 
#   geom_line(aes(color = grupo)) +
#   facet_wrap(~grupo) + 
#   geom_line(
#     data_ms_filter,
#     mapping = aes(x = fecha, y = dl4_ipc), color = "#3d5a80", size = 0.7) +
#   geom_hline(yintercept = 4) + 
#   scale_y_continuous(breaks = c(0,2,4,6,8,10)) +
#   theme_bw() +
#   labs(x = NULL, y = NULL) +
#   theme(
#     legend.position = "none",
#     axis.ticks = element_blank()
#   )
#   
# 
# 
# 
# 
# # Analisis de sensibilidad de las expectativas de inflación antes  --------
# 
# data_sensibilidad <- data_ms |> 
#   mutate(
#     inflacion_observada = lag(dl4_ipc),
#     delt_infl = (inflacion_observada - lag(inflacion_observada))
#   )
# 
# mod_sensibilidad <- lm(exp_inf ~ inflacion_observada + delt_infl, data = data_sensibilidad) 
# stargazer::stargazer(mod_sensibilidad, type = "text")
# 
# 
# # Midiendo efectos asimetricos
# 
# data_sensibilidad2 <- data_sensibilidad %>%
#   mutate(
#     delta_pos = pmax(delt_infl, 0),
#     delta_neg = pmin(delt_infl, 0) 
#   )
# 
# mod_max_min <- lm(exp_inf ~ inflacion_observada + delta_pos + delta_neg, data = data_sensibilidad2) 
# stargazer::stargazer(mod_sensibilidad, mod_max_min, type = "text")

























# Gráfico comparativo -----------------------------------------------------
# Expectativas, inflación y meta

data_ms |> 
  ggplot(aes(
    x = dl4_ipc, 
    y = exp_inf, 
    color = mas_meta
  )) +
    geom_point() +  # Puntos coloreados según mas_meta
    geom_smooth(method = "lm", se = FALSE, aes(group = mas_meta), size = 0.7) +  # Línea de regresión por categoría
    labs(
      title = NULL,
      x = "Inflación Interanual",
      y = "Expectativas de Inflación",
      color = "Inflación > Meta"
    ) +
    theme_minimal() +
    theme(
      legend.position = c(0.2,0.8), #"bottom", 
      panel.grid.major = element_line(color = "gray", linetype = 3, size = 0.1),
      panel.grid.minor = element_line(color = "gray", linetype = 3, size = 0.1),
      axis.text = element_text(size = 7),  # Tamaño del texto de los ejes
      axis.title = element_text(size = 7),  # Tamaño del texto de los títulos de los ejes
      strip.text = element_text(size = 7),  # Tamaño del texto en los paneles
      legend.text = element_text(size = 7),  # Tamaño del texto de la leyenda
      panel.border = element_rect(color = NA, fill = NA, size = 0.1), 
      legend.title = element_blank(),                   # Elimina el título de la leyenda
      legend.background = element_blank()              # Elimina el fondo/borde de la leyenda
    )