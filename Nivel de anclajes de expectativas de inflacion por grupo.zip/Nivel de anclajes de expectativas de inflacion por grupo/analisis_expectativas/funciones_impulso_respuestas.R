# Funciones de impulsos respuestas de las expectativas --------------------
library(tidyverse)
library(vars)
library(lmtest)
library(sandwich)
library(tseries)
library(forecast)
library(readxl)  # Para leer Excel


data_ms <- read_excel("./data/data.xlsx", sheet = "data_expect") |> 
  filter(fecha >= "2007-12-01")

data_infl <- data_ms %>%
  mutate(dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
         dev_pos = pmax(dl4_ipc - meta, 0),
         dev_neg = pmax(meta - dl4_ipc, 0),
         mas_meta = factor(dl4_ipc > meta)) %>%
  filter(!is.na(dl4_ipc))


# Impacto de inflación en las expectativas --------------------------------
# Convertir en serie de tiempo con las variables correctas
ts_data <- ts(data_infl[, c("exp_inf", "dl4_ipc")], start = c(2007, 1), frequency = 12)

# Verificar estacionariedad de las variables
adf_exp_inf <- adf.test(ts_data[, "exp_inf"])
adf_dl4_ipc <- adf.test(ts_data[, "dl4_ipc"])

print(adf_exp_inf)
print(adf_dl4_ipc)

# 3. Aplicar diferenciación si no son estacionarias
ts_data_diff <- diff(ts_data)  # Reduce la longitud en 1
ts_data_diff <- ts(ts_data_diff, start = c(2007, 2), frequency = 12)  # Convertir de nuevo a ts

# Seleccionar variables a modelar
ts_var_diff <- ts_data_diff[, c("exp_inf", "dl4_ipc")]

# 4. Selección del número óptimo de rezagos
lag_selection <- VARselect(ts_var_diff, lag.max = 10, type = "const")
optimal_lag <- lag_selection$selection[which.min(lag_selection$selection)]  # Seleccionar mínimo AIC

# 5. Ajustar modelo VAR
var_model <- VAR(ts_var_diff, p = optimal_lag, type = "const")

# 6. Función de Respuesta al Impulso (IRF) - Ahora usando dl4_ipc
irf_result <- irf(var_model, impulse = "dl4_ipc", response = "exp_inf", n.ahead = 20, boot = TRUE)

# 7. Graficar los resultados mejorados
plot(irf_result, main = "Respuesta al impulso: Impacto de inflación observada en expectativas de inflación")



# Impacto de la tasa de interes en las expectativas -----------------------
ts_data <- ts(data_ms[, c("exp_inf", "tia_180")], start = c(2007, 1), frequency = 12)

# 2. Verificar estacionariedad
adf.test(ts_data[, "exp_inf"]) # No es estacionaria
adf.test(ts_data[, "tia_180"]) # No es estacionaria

# 3. Aplicar diferenciación si no son estacionarias
ts_data_diff <- diff(ts_data)  # Reduce la longitud en 1
ts_data_diff <- ts(ts_data_diff, start = c(2007, 2), frequency = 12)  # Convertir de nuevo a ts

# Seleccionar variables a modelar
ts_var_diff <- ts_data_diff[, c("exp_inf", "tia_180")]

# 4. Selección del número óptimo de rezagos
lag_selection <- VARselect(ts_var_diff, lag.max = 10, type = "const")
optimal_lag <- lag_selection$selection[which.min(lag_selection$selection)]  # Seleccionar mínimo AIC

# 5. Ajustar modelo VAR
var_model <- VAR(ts_var_diff, p = optimal_lag, type = "const")

# 6. Función de Respuesta al Impulso (IRF)
irf_result <- irf(var_model, impulse = "tia_180", response = "exp_inf", n.ahead = 20, boot = TRUE)

# 7. Graficar los resultados mejorados
plot(irf_result, main = "Respuesta al impulso: Impacto de tasa de interés en expectativas de inflación")


# Descomposición de las expectativas --------------------------------------
ts_exp_inf <- ts(data_ms$exp_inf, start = c(2007, 1), frequency = 12)  # Mensual

# 2. Descomposición clásica de la serie
decomp_exp_inf <- decompose(ts_exp_inf, type = "multiplicative")  # También puedes probar "additive"

# 3. Graficar la descomposición
autoplot(decomp_exp_inf) +
  ggtitle("Descomposición de la serie expectativas de inflación a 12 meses") +
  theme_minimal()

# Analisis de los efectos de distintas crisis en las expectativas  --------



# 1. Obtener datos de TPM y calcular aumentos/disminuciones
tpm_data <- databcrd::get_tpm() |> 
  filter(year >= 2008) |> 
  mutate(
    aumento_tpm = as.integer(tpm > lag(tpm)),  # 1 si aumenta, 0 si no
    disminucion_tpm = as.integer(tpm < lag(tpm))  # 1 si disminuye, 0 si no
  ) |> 
  select(fecha, tpm, aumento_tpm, disminucion_tpm)

# 2. Cargar datos macroeconómicos (data_ms) y unir con TPM
data_ms <- read_excel("./data/data.xlsx", sheet = "data_expect") |> 
  filter(fecha >= "2007-12-01") |> 
  left_join(tpm_data)  |> 
  mutate(tpm = tpm * 100)

# 3. Crear variables dummy para eventos macroeconómicos
data_ms <- data_ms %>%
  mutate(
    crisis_2008 = as.integer(fecha >= "2008-09-01" & fecha <= "2010-06-01"),
    crisis_petroleo = as.integer(fecha >= "2014-06-01" & fecha <= "2016-12-01"),
    covid = as.integer(fecha >= "2020-03-01" & fecha <= "2021-12-01"),
    # subidas_tasas = as.integer(fecha >= "2022-01-01")
  )

# 4. Ajustar modelo de regresión con las dummies y la TPM
modelo_eventos <- lm(exp_inf ~ crisis_2008 + crisis_petroleo + covid +  aumento_tpm + disminucion_tpm, 
                     data = data_ms)

# 5. Resumen del modelo
stargazer::stargazer(modelo_eventos, type = "text")

# 6. Verificar significancia estadística de las variables
coeftest(modelo_eventos, vcov = vcovHC(modelo_eventos, type = "HC1"))




ggplot(data_ms, aes(x = fecha)) +
  geom_line(aes(y = tpm, color = "TPM"), size = 1) +
  geom_line(aes(y = exp_inf, color = "Expectativas de Inflación"), size = 1, linetype = "dashed") +
  labs(title = "Evolución de la TPM y Expectativas de Inflación",
       y = "Valor", x = "Fecha") +
  scale_color_manual(values = c("TPM" = "blue", "Expectativas de Inflación" = "red")) +
  theme_minimal()

#  Gráfico de barras: Aumentos y Disminuciones de TPM
ggplot(data_ms, aes(x = fecha, y = exp_inf)) +
  geom_bar(stat = "identity", aes(fill = factor(aumento_tpm - disminucion_tpm)), show.legend = FALSE) +
  scale_fill_manual(values = c("-1" = "red", "1" = "green", "0" = "gray")) +
  labs(title = "Impacto de Aumentos/Disminuciones de TPM en Expectativas de Inflación",
       x = "Fecha", y = "Exp. Inflación") +
  theme_minimal()

# Boxplot: Comparación de Exp_inf según la política monetaria
ggplot(data_ms, aes(x = factor(aumento_tpm - disminucion_tpm), y = exp_inf)) +
  geom_boxplot(aes(fill = factor(aumento_tpm - disminucion_tpm))) +
  scale_fill_manual(values = c("-1" = "red", "1" = "green", "0" = "gray")) +
  labs(title = "Distribución de Expectativas de Inflación según Cambios en TPM",
       x = "Cambio en TPM", y = "Expectativas de Inflación") +
  theme_minimal()

# 4️⃣ Gráfico de dispersión: Relación entre TPM y Exp_inf
ggplot(data_ms, aes(x = tpm, y = exp_inf)) +
  geom_point(aes(color = factor(aumento_tpm - disminucion_tpm)), size = 2, alpha = 0.7) +
  geom_smooth(method = "lm", color = "black", linetype = "dashed") +
  scale_color_manual(values = c("-1" = "red", "1" = "green", "0" = "gray")) +
  labs(title = "Relación entre TPM y Expectativas de Inflación",
       x = "TPM", y = "Expectativas de Inflación") +
  theme_minimal()
