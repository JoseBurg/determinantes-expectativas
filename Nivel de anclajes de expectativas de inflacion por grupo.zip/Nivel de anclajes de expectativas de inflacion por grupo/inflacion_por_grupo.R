library(tidyverse)

# Notas -------------------------------------------------------------------
# 1. Este script solo se puede usar en el proyecto de procesamiento.

# Cargando funciones y objetos utilitarios --------------------------------
source(here::here('general_scripts', 'utilitarios.R'), encoding = "UTF-8")
source(here::here('eem/scripts/functions/handling_data.R'), encoding = "UTF-8")
source(here::here('eem/scripts/functions/graficos.R'), encoding = "UTF-8")
source(here::here('eem/scripts/functions/write_excel_outputs.R'), encoding = "UTF-8")

# Expectativas de inflacion por grupos ------------------------------------

eem_grupos <- get_eem_historic() |> 
  filter(
    !is.na(grupo), 
    !stringr::str_detect(grupo,"Empresas|No se sabe|No sabe")) |> 
  rename(
    "inf_12" = inflacion_interanual,
    "inf_24" = inflacion_interanual2
  ) |> 
  # group_by(periodo, grupo) |> 
  # summarise(
  #   across(c(
  #     inf_12,
  #     inf_24),
  #     list(mediana = median, 
  #          promedio = mean), 
  #          na.rm = TRUE),
  #   .by = c(periodo, grupo)
  #   ) |> 
  as_tibble()

eem_grupos |> 
  select(periodo, grupo, inf_12, inf_24) |> 
  clipr::write_clip()


correlacion_mediana_12 <- 
eem_grupos |> 
  select(periodo, inf_12_mediana, grupo) |> 
  pivot_wider(id_cols = periodo, names_from = grupo, 
              values_from = inf_12_mediana)

correlacion_mediana_24 <- 
eem_grupos |> 
  select(periodo, inf_24_mediana, grupo) |> 
  pivot_wider(id_cols = periodo, names_from = grupo, 
              values_from = inf_24_mediana)

cor(correlacion_mediana_12[,c(2:6)], use = "na.or.complete") |> 
  clipr::write_clip()

cor(correlacion_mediana_24[,c(2:6)], use = "na.or.complete") |> 
  clipr::write_clip()

eem_grupos |> 
  filter(periodo >= "2015-01-01") |> 
  ggplot(aes(x = periodo)) +
  geom_line(aes(y = inf_12_mediana)) +
  geom_hline(yintercept = 5, type = 1) +
  geom_hline(yintercept = 3) +
  scale_y_continuous(breaks = c(0,3,5,7,10)) +
  labs(title = "Inflación mediana a 12 meses", 
       y = "Inflación")+
  facet_wrap(~grupo)

# Promedio movil de 3 meses
eem_grupos |> 
  filter(periodo >= "2015-01-01") |> 
  summarise(inf_12_mediana = zoo::rollmean(inf_12_mediana,  k = 3, align = "right"),
            .by = c(periodo, grupo)) |> 
  ggplot(aes(x = periodo)) +
  geom_line(aes(y = inf_12_mediana)) +
  geom_hline(yintercept = 5, type = 1) +
  geom_hline(yintercept = 3) +
  scale_y_continuous(breaks = c(0,3,5,7,10)) +
  labs(title = "Inflación mediana a 12 meses", 
       subtitle = "Moving average 3M",
       y = "Inflación")+
  facet_wrap(~grupo)

eem_grupos |>
  ggplot(aes(x = periodo)) +
  geom_line(aes(y = inflacion_interanual2_1)) +
  geom_hline(yintercept = 5) +
  geom_hline(yintercept = 3) +
  scale_y_continuous(breaks = c(0,3,5,7,10)) +
  labs(title = "Inflación mediana a 24 meses", 
       y = "Inflación")+
  facet_wrap(~grupo)
  

# Conteo por analista según grupo  ----------------------------------------

eem_conteo <- get_eem_historic() |> 
  filter(!is.na(grupo), 
         # year >= 2016, 
         !grupo == "Empresas") |> 
  select(
    periodo, grupo,
    inflacion_interanual
    # inflacion_interanual2
  )

eem_conteo |> 
  count(periodo, grupo) |> 
  filter(periodo >= "2018-01-01") |> 
  # pivot_wider(
  #   names_from = grupo, 
  # ) |> 
  ggplot() + 
  geom_col(
    aes(periodo, n, fill = grupo), 
    width = 31) +
  annotate("text", x = as.Date("2024-03-01"), y = 26, label = "25" )  +
  labs(fill = "", x = "", y = "") + 
  geom_hline(yintercept = 25) +
  scale_fill_manual(values = c("#124559", "#748cab", "#00a8e8", "#007ea7", "#003459", "#3c6e71")) +
  scale_x_date(labels = date_label)+
  theme_em()

eem_conteo |> 
  count(periodo, grupo) |> 
  filter(periodo >= "2018-01-01") |>
  # pivot_wider(
  #   names_from = grupo, 
  # ) |> 
  ggplot() + 
  geom_col(
    aes(periodo, n, fill = grupo), 
    width = 31) +
  facet_wrap(~grupo) + 
  scale_fill_manual(values = c("#124559", "#748cab", "#00a8e8", "#007ea7", "#003459", "#3c6e71")) +
  scale_x_date(labels = date_label)+
  theme_em()
