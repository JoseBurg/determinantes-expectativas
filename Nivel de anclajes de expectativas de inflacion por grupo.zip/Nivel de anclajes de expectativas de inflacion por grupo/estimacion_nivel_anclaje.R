# Funciones de impulsos respuestas de las expectativas --------------------
library(tidyverse)
library(vars)
library(lmtest)
library(sandwich)
library(tseries)
library(forecast)
library(readxl)  # Para leer Excel

# Cargar datos y unir -----------------------------------------------------
data_ms <- read_excel("C:/Users/2016023/OneDrive - BCRD/Desktop/Data personal de jose/Investigaciones/Nivel de anclajes de expectativas de inflacion por grupo/analisis_expectativas/data/data.xlsx", sheet = "data_expect")

# Simulación de datos (si tienes datos reales, reemplaza esta parte con read.csv)
data_inflacion <- data_ms |> 
  mutate(
    pi_meta = 4, 
    dl4_ipc = 100 * (IPC / dplyr::lag(IPC,12) - 1),
    pi_t_1 = lag(dl4_ipc)
  ) |> filter(!is.na(pi_t_1))



# Revisar la estructura de los datos
summary(data_inflacion)

# Verificar si pi_meta es constante
if (length(unique(data_inflacion$pi_meta)) > 1) {
  data_inflacion <- data_inflacion %>%
    mutate(pi_meta_scaled = (pi_meta - min(pi_meta)) / (max(pi_meta) - min(pi_meta)))
} else {
  data_inflacion$pi_meta_scaled <- data_inflacion$pi_meta  # Usar valores originales si es constante
}

# Normalizar exp_inf y pi_t_1 solo si hay variabilidad
data_inflacion <- data_inflacion %>%
  mutate(exp_inf_scaled = ifelse(max(exp_inf) == min(exp_inf), exp_inf, 
                                 (exp_inf - min(exp_inf)) / (max(exp_inf) - min(exp_inf))),
         pi_t_1_scaled = ifelse(max(pi_t_1) == min(pi_t_1), pi_t_1, 
                                (pi_t_1 - min(pi_t_1)) / (max(pi_t_1) - min(pi_t_1))))

# Ajustar valores iniciales para lambda_meta
lambda_init <- mean(data_inflacion$exp_inf_scaled) / mean(data_inflacion$pi_meta_scaled + data_inflacion$pi_t_1_scaled)
lambda_init <- min(max(lambda_init, 0.01), 0.99)  # Asegurar que esté en (0,1)

# Estimación con nlsLM() usando tryCatch para evitar errores
modelo_nls <- tryCatch({
  nlsLM(
    exp_inf_scaled ~ lambda_meta * pi_meta_scaled + (1 - lambda_meta) * pi_t_1_scaled,
    data = data_inflacion,
    start = list(lambda_meta = lambda_init)
  )
}, error = function(e) {
  print("Error en nlsLM, ajustando valores iniciales...")
  return(NULL)
})

# Verificar si el modelo fue exitoso
if (!is.null(modelo_nls)) {
  print(summary(modelo_nls))
  print(coef(modelo_nls))
} else {
  print("El modelo no pudo ajustarse correctamente.")
}

# Graficar los resultados
if (!is.null(modelo_nls)) {
  data_inflacion <- data_inflacion %>%
    mutate(ajuste = predict(modelo_nls) * (max(exp_inf) - min(exp_inf)) + min(exp_inf))
  
  ggplot(data_inflacion, aes(x = fecha)) +
    geom_line(aes(y = exp_inf, color = "Expectativa 12M"), size = 1) +
    geom_line(aes(y = ajuste, color = "Modelo Ajustado"), size = 1) +
    labs(title = "Anclaje de las Expectativas de Inflación a la Meta del Banco Central",
         subtitle = "Estimación basada en Bomfim y Rudebusch (2000)",
         x = "Fecha",
         y = "Inflación (%)",
         color = "Serie") +
    theme_minimal() +
    scale_color_manual(values = c("Expectativa 12M" = "red", "Modelo Ajustado" = "blue"))
}
